# Momentum Mobile Website V2

## What is included
- Mobile-first MOMO / Momentum Mobile design
- Services section
- Quote request form
- Customer name, phone, email, ZIP, preferred contact method
- Service selection, detailed job description, address, timing, budget
- Optional photo upload
- Ready for a form-email service

## Before publishing
1. Open `index.html`.
2. Find `YOUR_FORM_ENDPOINT`.
3. Replace it with the endpoint from your chosen form service.
4. Test the form from a phone.
5. Publish the folder with your hosting provider.

Recommended production setup:
- A custom domain you own
- HTTPS
- A form service that forwards submissions to your business email
- Optional business email/domain mailbox
